package com.api.rest.clases;

public class Tarjetas {

	private String transactionID;
	private String transactionDate;
	private String transactionTime;
	private String nroCuentaPrimaria;
	private String fecVencimiento;
	private String codServicio;

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String gettransactionDate() {
		return transactionDate;
	}

	public void settransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getnroCuentaPrimaria() {
		return nroCuentaPrimaria;
	}

	public void setnroCuentaPrimaria(String nroCuentaPrimaria) {
		this.nroCuentaPrimaria = nroCuentaPrimaria;
	}

	public String getfecVencimiento() {
		return fecVencimiento;
	}

	public void setfecVencimiento(String fecVencimiento) {
		this.fecVencimiento = fecVencimiento;
	}

	public String getcodServicio() {
		return codServicio;
	}

	public void setcodServicio(String codServicio) {
		this.codServicio = codServicio;
	}





}
